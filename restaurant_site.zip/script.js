// Toggle menu mobile
const toggle = document.getElementById('nav-toggle');
const menu   = document.getElementById('nav-menu');
toggle.addEventListener('click', () => {
  menu.classList.toggle('show');
});

// Simula envio de reserva
const form   = document.getElementById('reserva-form');
const msgBox = document.getElementById('reserva-msg');
form.addEventListener('submit', e => {
  e.preventDefault();
  msgBox.textContent = '🎉 Reserva enviada com sucesso!';
  msgBox.style.color = 'green';
  form.reset();
});
